package org.scriptum.reader

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

data class ScriptumScript(val id: String, val title: String, val glyphs: String, val examples: String)

object ScriptumScripts {
    val all = listOf(
        ScriptumScript("greek", "Греческое письмо · Ελληνικά", "Α Β Γ Δ Ε Ζ", "καλημέρα · νερό · φως"),
        ScriptumScript("georgian", "Грузинское письмо · ქართული", "ა ბ გ დ ე ვ", "გამარჯობა · წყალი · მზე"),
        ScriptumScript("armenian", "Армянское письмо · Հայոց գրեր", "Ա Բ Գ Դ Ե Զ", "բարև · ջուր · լույս"),
        ScriptumScript("tifinagh", "Тифинаг · ⵜⵉⴼⵉⵏⴰⵖ", "ⴰ ⴱ ⴳ ⴷ ⴹ ⴻ", "ⴰⵎⴰⵣⵉⵖ · ⴰⴼⵓⵙ · ⴰⵣⵓⵍ"),
        ScriptumScript("hebrew", "Иврит · עברית", "א ב ג ד ה ו", "שלום · מים · ספר"),
        ScriptumScript("devanagari", "Деванагари · देवनागरी", "अ आ इ ई उ ऊ", "नमस्ते · पानी · घर"),
        ScriptumScript("hangul", "Хангыль · 한글", "ㄱ ㄴ ㄷ ㄹ ㅁ ㅂ", "안녕 · 나무 · 바다"),
        ScriptumScript("japanese", "Японская кана · かな", "あ い う ア イ ウ", "ひらがな · カタカナ · さくら"),
        ScriptumScript("burmese", "Бирманское письмо · မြန်မာ", "က ခ ဂ ဃ င စ", "မင်္ဂလာပါ · မြန်မာ · စာ"),
        ScriptumScript("tibetan", "Тибетское письмо · བོད་ཡིག", "ཀ ཁ ག ང ཅ ཆ", "བོད · ཆུ · མི"),
        ScriptumScript("inuktitut", "Инуктитут · ᐃᓄᒃᑎᑐᑦ", "ᐃ ᐅ ᐊ ᐱ ᐳ ᐸ", "ᐃᓄᒃᑎᑐᑦ · ᐊᓂ · ᐃᒡᓗ"),
        ScriptumScript("cherokee", "Чероки · ᏣᎳᎩ", "Ꭰ Ꭱ Ꭲ Ꭳ Ꭴ Ꭵ", "ᏣᎳᎩ · ᎠᏂᏴᏫ · ᎤᏃᎯᏳᎯ")
    )
    fun byId(id: String?): ScriptumScript = all.firstOrNull { it.id == id } ?: all.first()
}

class ScriptumWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { updateOne(context, manager, it) }
    }

    companion object {
        fun updateOne(context: Context, manager: AppWidgetManager, widgetId: Int) {
            val prefs = context.getSharedPreferences("scriptum_widget_$widgetId", Context.MODE_PRIVATE)
            val script = ScriptumScripts.byId(prefs.getString("script_id", "greek"))
            val views = RemoteViews(context.packageName, R.layout.scriptum_widget)
            views.setTextViewText(R.id.widget_title, script.title)
            views.setTextViewText(R.id.widget_glyphs, script.glyphs)
            views.setTextViewText(R.id.widget_examples, script.examples)
            val open = Intent(context, MainActivity::class.java)
            val pending = PendingIntent.getActivity(
                context, widgetId, open,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_root, pending)
            manager.updateAppWidget(widgetId, views)
        }
    }
}
