package org.scriptum.reader

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView

class WidgetConfigureActivity : Activity() {
    private var widgetId = AppWidgetManager.INVALID_APPWIDGET_ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_CANCELED)
        widgetId = intent?.extras?.getInt(
            AppWidgetManager.EXTRA_APPWIDGET_ID,
            AppWidgetManager.INVALID_APPWIDGET_ID
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish()
            return
        }

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 20)
        }
        layout.addView(TextView(this).apply {
            text = "Выбери письменность для виджета Scriptum"
            textSize = 18f
        })
        val spinner = Spinner(this)
        val titles = ScriptumScripts.all.map { it.title }
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, titles)
        layout.addView(spinner)
        layout.addView(TextView(this).apply {
            text = "На главном экране появятся название письменности, её знаки и три примера слов."
            textSize = 13f
            setPadding(0, 14, 0, 16)
        })
        layout.addView(Button(this).apply {
            text = "Создать виджет"
            setOnClickListener {
                val script = ScriptumScripts.all[spinner.selectedItemPosition]
                getSharedPreferences("scriptum_widget_$widgetId", MODE_PRIVATE)
                    .edit().putString("script_id", script.id).apply()
                ScriptumWidgetProvider.updateOne(
                    this@WidgetConfigureActivity,
                    AppWidgetManager.getInstance(this@WidgetConfigureActivity),
                    widgetId
                )
                val result = Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
                setResult(RESULT_OK, result)
                finish()
            }
        })
        setContentView(layout)
    }
}
