plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "org.scriptum.reader"
    compileSdk = 35
    defaultConfig {
        applicationId = "org.scriptum.reader"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
